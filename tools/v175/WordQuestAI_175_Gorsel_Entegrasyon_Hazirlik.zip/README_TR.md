# WordQuest AI 1.0.75 — Birleştirilmiş Kullanıcı Görsel Entegrasyonu

Bu paket **yüklenen gerçek görsel dosyalarından** oluşturuldu. Yeni resim üretimi yapılmadı.

## İçerik

- 102 bağımsız 512×512 şeffaf WebP ana ikon (öncelikli); 6 yüksek kaliteli tasarım için kolay isim takma adları
- 108 adet düşük ayrıntılı panodan kesilmiş ikon (yalnızca ikincil/yedek ikon olarak)
- 18 yumuşak renkli sayfa arka planı ve 18 görsel banner
- 14 tematik sahne görseli, 12 kart zemini ve 6 buton zemini
- Kotlin `Wq175UserArt.kt`: görseli bağımsız yükler ve mevcut grafiğe otomatik geri döner
- `install_user_art.py`: mevcut Android kaynağına dekoratif görselleri ve ikon yönlendirmesini uygular.

## Korumalar

1. **Kelime Hafızam** ekranının iç tasarımı ve **Ana Sayfa** onaylı düzeni değiştirilmez; yalnızca menü ikonları yeni çizimlere döner.
2. **Arena** için onaylı altın-mor kupa ikonuna öncelik verilir; gerçek karakter/animasyon üst katmanı bağımsız kalır.
3. **Eşleştirmelerim**, Bulmacalarım altında saklanmaz; bağımsız rota ve menü olmalıdır.
4. **Lena** veya diğer çalışan konuşma sistemi değiştirilmez.
5. Kadın/erkek karakterler için maksimum 5 reaksiyon; dini/mesleki etiketlerden kaçınılır; Zeynep eklenmez.
6. Kaynak PDF bir karakter konseptidir; buradaki figürler gerçek rigli sprite ya da animasyon değildir.

## Kurulum (CI içinde, v175 overlay'lerinden sonra)

`python3 install_user_art.py --project source`

**Not:** `source/` veya `android-current/` önceden açılmış gerçek Android projesi olmalıdır. Bu paket yalnızca bir entegrasyon katmanıdır; imzalı APK veya yayına çıkmış bir güncelleme değildir. Doğru derleme, sürüm kodu ve aynı imza ile yayımlama ayrı kontroldür.
