#!/usr/bin/env python3
"""Run once after the existing v175 overlays to activate supplied user art.

Input: a materialized Android project source tree (with src/main). This script
never changes package IDs, version numbers, signing, app navigation or game logic.
"""
from pathlib import Path
import argparse, shutil, sys

HERE=Path(__file__).resolve().parent
ASSETS=HERE/'assets'/'wq175_user_art'

def install(project: Path):
    src=project/'app/src/main'
    kotlin_dir=src/'java/com/kelimebulmacasi/a1'
    assert kotlin_dir.is_dir(),f'Expected materialized Android source: {kotlin_dir}'
    assert (kotlin_dir/'WordQuest175Icons.kt').is_file(), 'Run existing 1.0.75 overlays first'
    assert (kotlin_dir/'WordQuest175ThemeArt.kt').is_file(), 'Run existing 1.0.75 overlays first'
    dst=src/'assets'/'wq175_user_art'
    dst.mkdir(parents=True,exist_ok=True)
    for p in ASSETS.rglob('*'):
        if not p.is_file(): continue
        output=dst/p.relative_to(ASSETS)
        output.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,output)
    shutil.copyfile(HERE/'Wq175UserArt.kt',kotlin_dir/'Wq175UserArt.kt')
    iconfile=kotlin_dir/'WordQuest175Icons.kt'
    t=iconfile.read_text('utf-8')
    old="""        runCatching {
            context.assets.open("wq175_icons/" + name + ".webp").use { stream ->
                BitmapFactory.decodeStream(stream)?.asImageBitmap()
            }
        }.getOrNull()"""
    new="""        wq175LoadUserArt(context, "icons", Wq175UserArtMap.icon(name))
            ?: runCatching {
                context.assets.open("wq175_icons/" + name + ".webp").use { stream ->
                    BitmapFactory.decodeStream(stream)?.asImageBitmap()
                }
            }.getOrNull()"""
    if old in t:
        t=t.replace(old,new,1)
        iconfile.write_text(t,'utf-8')
    elif new not in t:
        raise AssertionError('Unexpected WordQuest175Icons.kt layout: no replacement made')
    themefile=kotlin_dir/'WordQuest175ThemeArt.kt'
    t=themefile.read_text('utf-8')
    old="""    Image(painter=painterResource(Wq175ThemeArt.icon(slug)),
        contentDescription=null,modifier=modifier,contentScale=ContentScale.Fit)"""
    new="""    Wq175UserArtImage("icons", slug, modifier, contentScale = ContentScale.Fit)"""
    if old in t:
        t=t.replace(old,new,1)
        themefile.write_text(t,'utf-8')
    elif new not in t:
        raise AssertionError('Unexpected Wq175ThemeIcon implementation')
    # Do not patch Home/Memory screens or turn on background wallpapers blindly;
    # backgrounds remain opt-in via Wq175UserArtImage("backgrounds", slug, ...).
    print('Installed:', len(list(dst.rglob('*.webp'))), 'WebP plus icon routing')
    print('Unchanged: navigations, all gameplay, approved home/memory layout, signing, versionCode')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project',required=True,help='root of source/ or android-current/')
    args=parser.parse_args()
    install(Path(args.project))
