package com.kelimebulmacasi.a1

import android.graphics.BitmapFactory
import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import java.util.Locale

/** High resolution independent user artworks; never display a whole sprite atlas. */
internal object Wq175UserArtMap {
    private val aliases = mapOf(
        "trophy" to "arena", "yds" to "yds_akademi", "cards" to "kelime_hafizam",
        "synonym" to "eslestirmelerim", "plan" to "gunluk_plan",
        "packages" to "hazir_paketler", "grammar" to "dilbilgisi",
        "paragraph" to "paragraf", "translate" to "ceviri",
        "completion" to "cumle_tamamlama", "exam" to "tam_deneme",
        "review" to "yanlis_analizi", "puzzle" to "bulmacalarim",
        "assistant" to "konusma_asistani", "speak" to "konusma_pratigi",
        "listen" to "telaffuz", "sentence" to "cumle_tamamlama",
        "analytics" to "istatistikler", "insights" to "ipucu", "friends" to "arkadaslar",
        "account" to "profil", "settings" to "ayarlar", "backup" to "yedekleme",
        "history" to "sohbet_gecmisi", "library" to "kelime_sozlugu",
        "streak" to "seri", "messages" to "mesajlar", "mistakes" to "yanlis_analizi",
        "ai_teacher" to "ai_ogretmen", "pdf" to "pdf_olustur", "camera" to "kamera",
        "scan" to "gorsel_ve_kamera", "notebook" to "taslaklarim",
        "timer" to "mini_deneme", "success" to "basarilar", "verbs" to "fiiller",
        "story" to "senaryo_ile_pratik", "arena_duel" to "arena_duello",
        "arena_team" to "arena_ortak_bulmaca", "arena_quiz" to "arena_5_sikli_duello",
        "level_a1" to "a1", "level_a2" to "a2", "level_b1" to "b1",
        "level_b2" to "b2", "level_c1" to "c1", "level_c2" to "c2"
    )
    fun icon(name: String): String = aliases[name] ?: name
    fun sectionForTitle(title: String): String? {
        val s = title.lowercase(Locale.forLanguageTag("tr-TR"))
        return when {
            "eşleştir" in s -> "eslestirmelerim"
            "arena" in s || "turnuva" in s -> "arena"
            "yds" in s -> "yds_akademi"
            "hafıza" in s -> "kelime_hafizam"
            "dilbilgisi" in s -> "dilbilgisi"
            "paragraf" in s -> "paragraf"
            "çeviri" in s -> "ceviri"
            "günlük" in s || "plan" in s -> "gunluk_plan"
            "paket" in s -> "hazir_paketler"
            "bulmaca" in s -> "bulmacalarim"
            "konuşma" in s -> "konusma_asistani"
            "yeni oyun" in s -> "yeni_oyun"
            "başarı" in s -> "basarilar"
            "profil" in s -> "profil"
            "ayar" in s -> "ayarlar"
            else -> null
        }
    }
}

/** Return null on missing icons so previous artwork stays functional. */
internal fun wq175LoadUserArt(context: Context, folder: String, slug: String): androidx.compose.ui.graphics.ImageBitmap? {
    val safeName = slug.takeIf { it.matches(Regex("[a-z0-9_]+")) } ?: return null
    val safeFolder = folder.takeIf { it.matches(Regex("[a-z]+")) } ?: return null
    return runCatching {
        context.assets.open("wq175_user_art/$safeFolder/$safeName.webp").use { stream ->
            BitmapFactory.decodeStream(stream)?.asImageBitmap()
        }
    }.getOrNull()
}

@Composable
internal fun Wq175UserArtImage(
    folder: String,
    slug: String,
    modifier: Modifier = Modifier,
    contentDescription: String? = null,
    contentScale: ContentScale = ContentScale.Fit,
) {
    val context = LocalContext.current
    val bitmap = remember(context, folder, slug) { wq175LoadUserArt(context, folder, slug) }
    if (bitmap != null) Image(bitmap = bitmap, contentDescription = contentDescription,
        modifier = modifier, contentScale = contentScale)
}
