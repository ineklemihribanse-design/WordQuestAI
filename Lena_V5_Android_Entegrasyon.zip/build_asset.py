import json, struct, pathlib, zipfile, sys, hashlib
p=pathlib.Path(sys.argv[1]); out=pathlib.Path(sys.argv[2]); raw=zipfile.ZipFile(p).read('Lena_V4_Ses_Test.glb') if p.suffix=='.zip' else p.read_bytes()
assert raw[:4]==b'glTF'; n=struct.unpack_from('<I',raw,12)[0]; d=json.loads(raw[20:20+n]); blen=struct.unpack_from('<I',raw,20+n)[0]; b=bytearray(raw[28+n:28+n+blen]); assert len(d['skins'][0]['joints'])==201
assert d['meshes'][0]['extras']['targetNames']==['Viseme_AA','Viseme_EE','Viseme_OO','Viseme_UU','Viseme_MBP','Viseme_FV','Smile','Blink','BrowRaise']
node=next(i for i,x in enumerate(d['nodes']) if x.get('mesh')==0)
def acc(values):
    while len(b)%4:b.append(0)
    off=len(b); b.extend(struct.pack('<'+'f'*len(values),*values)); vi=len(d['bufferViews']);d['bufferViews'].append(dict(buffer=0,byteOffset=off,byteLength=len(values)*4)); i=len(d['accessors']);d['accessors'].append(dict(bufferView=vi,componentType=5126,count=len(values),type='SCALAR',min=[min(values)],max=[max(values)]));return i
# Two keyframes: caller samples 0..1 seconds as strength; all weights have one owner.
ti=acc([0.,1.]); mapping={'NEUTRAL':None,'A':0,'E':1,'I':1,'O':2,'U':3,'MBP':4}
for name,idx in mapping.items():
    for blink in (False,True):
        a=[0.]*9; z=a.copy(); a[7]=z[7]=float(blink)
        if idx is not None:z[idx]=1.
        d['animations'].append(dict(name='Lena_V5_Face_'+name+('_Blink' if blink else ''),samplers=[dict(input=ti,output=acc(a+z),interpolation='LINEAR')],channels=[dict(sampler=0,target=dict(node=node,path='weights'))]))
assert len(d['animations'])==73
assert len({x['name'] for x in d['animations']})==73
d['buffers'][0]['byteLength']=len(b);j=json.dumps(d,separators=(',',':')).encode();j+=b' '*(-len(j)%4);b+=b'\0'*(-len(b)%4)
res=struct.pack('<4sII',b'glTF',2,28+len(j)+len(b))+struct.pack('<I4s',len(j),b'JSON')+j+struct.pack('<I4s',len(b),b'BIN\0')+b
out.write_bytes(res); print('PASS 201 joints, 73 clips, 14 independently sampled face clips',len(res),hashlib.sha256(res).hexdigest())
