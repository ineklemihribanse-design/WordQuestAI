package com.kelimebulmacasi.a1
fun main() {
    val d = listOf("Mixamo_Idle","Mixamo_Talking","Mixamo_Talking-1","Mixamo_Talking-2","Mixamo_Talking-3","Mixamo_Thinking","Mixamo_Thoughtful_Head_Nod").associateWith { 4f }
    val c = LenaV5Motion(d)
    check(c.frame(1000,"IDLE",1f,"A",1f).faceTime==0f)
    val first = c.frame(1100,"SPEAKING",1f,"A",.8f)
    check(first.body=="Mixamo_Talking" && first.previous=="Mixamo_Idle" && first.alpha==0f)
    val half = c.frame(1250,"SPEAKING",1f,"A",.8f)
    check(half.alpha==.5f && half.faceTime in .79f.. .81f)
    check(c.frame(1400,"SPEAKING",1f,"A",.8f).previous==null)
    check(c.frame(1450,"LISTENING",1f,"A",1f).faceTime==0f)
    check(c.frame(1800,"SPEAKING",1f,"MBP",1f).body=="Mixamo_Talking-1")
    check(c.frame(4490,"IDLE",1f,"A",1f).face.endsWith("_Blink"))
    check(c.frame(10,"ERROR",1f,"A",1f).faceTime==0f)
    println("PASS: idle, talk rotation, 300ms blend, silence, blink and clock reset")
}
