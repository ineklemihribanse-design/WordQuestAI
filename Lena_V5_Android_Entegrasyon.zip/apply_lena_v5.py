#!/usr/bin/env python3
"""Apply only to an assembled WordQuest Android source tree, on a QA branch."""
import hashlib, pathlib, shutil, sys
here=pathlib.Path(__file__).resolve().parent
root=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else 'source')
app=root/'app/src/main/java/com/kelimebulmacasi/a1'
p=app/'LenaLive3DStage.kt'; s=p.read_text(); assert 'LenaV5Motion' not in s
asset=here/'Lena_V5_Runtime.glb'; assert hashlib.sha256(asset.read_bytes()).hexdigest()=='ff5989c5056596fc487973e87974794603981890fec8a3dcb83561683f4f3a4d'
def once(old,new):
 global s
 assert s.count(old)==1, f'Expected unique anchor: {old[:100]}'
 s=s.replace(old,new,1)
once('"avatars/lena/Lena_Prism3D_AnimationPack_v6.glb"','"avatars/lena/Lena_V5_Runtime.glb"')
# Only the Lena isolated process uses this model. Keep its existing recovery path.
a=s.index('    LaunchedEffect(node, motion, speechRate) {'); b=s.index('\n    Box(modifier.background',a)
s=s[:a]+'''    val scheduler = remember(node) {
        node?.let { model -> LenaV5Motion(clips.mapValues { (_, index) -> model.animator.getAnimationDuration(index) }) }
    }
    val liveMotion by rememberUpdatedState(motion)
    val liveMouth by rememberUpdatedState(mouthCue)
    val liveRate by rememberUpdatedState(speechRate)
    var frameFailed by remember(node) { mutableStateOf(false) }
    LaunchedEffect(frameFailed) { if (frameFailed) onRecoverableError() }
'''+s[b:]
once('''                    onFrame = { _ ->
                        if (!observedFrame) observedFrame = true
                    },''','''                    onFrame = { _ ->
                        if (!frameFailed && scheduler != null) {
                            runCatching {
                                val now = android.os.SystemClock.elapsedRealtime()
                                val cue = liveMouth
                                val active = cue.quality != LipSyncQuality.NONE && cue.cueAtMs > 0 &&
                                    now - cue.cueAtMs in 0L..190L
                                val f = scheduler.frame(now, liveMotion.name, liveRate,
                                    cue.viseme.name, if (active) cue.weight else 0f)
                                val animator = node.animator
                                animator.applyAnimation(checkNotNull(clips[f.body]), f.time)
                                f.previous?.let { prior ->
                                    animator.applyCrossFade(checkNotNull(clips[prior]), f.previousTime, f.alpha)
                                }
                                // One facial animation owns all nine morph weights; no second loop.
                                animator.applyAnimation(checkNotNull(clips[f.face]), f.faceTime)
                                animator.updateBoneMatrices()
                                if (!observedFrame) observedFrame = true
                            }.onFailure {
                                Log.e("WQLenaV5", "Experimental playback failed", it)
                                frameFailed = true
                            }
                        }
                    },''')
assert 'model.playAnimation(' not in s
assert 'onRecoverableError()' in s
assert 'Lena_V5_Runtime.glb' in s
# Verify everything before changing the assembled tree.
assert (here/'LenaV5Motion.kt').is_file()
assert not (app/'LenaV5Motion.kt').exists()
assets=root/'app/src/main/assets/avatars/lena'; assert assets.is_dir()
assert not (assets/asset.name).exists()
shutil.copyfile(asset,assets/asset.name)
shutil.copyfile(here/'LenaV5Motion.kt',app/'LenaV5Motion.kt')
p.write_text(s)
print('PASS: installed experimental Lena-only model and motion controller. Original model, puzzle, Arena and app version untouched.')
