package com.kelimebulmacasi.a1

/** Lena-only motion scheduler. Caller owns the render thread and animation clock. */
internal class LenaV5Motion(private val durations: Map<String, Float>) {
    data class Frame(val body: String, val time: Float, val previous: String?, val previousTime: Float, val alpha: Float, val face: String, val faceTime: Float)
    private var current = "Mixamo_Idle"
    private var previous: String? = null
    private var start = -1L
    private var prevStart = -1L
    private var currentRate = 1f
    private var prevRate = 1f
    private var lastMode = ""
    private var talkIndex = 0
    private var faceAmount = 0f
    private var lastFrame = -1L
    private var faceViseme = "NEUTRAL"
    private val talk = listOf("Mixamo_Talking", "Mixamo_Talking-1", "Mixamo_Talking-2", "Mixamo_Talking-3")
    private fun time(clip: String, epoch: Long, now: Long, rate: Float): Float {
        val duration = (durations[clip] ?: 1f).coerceAtLeast(.001f)
        return ((now - epoch).coerceAtLeast(0L) / 1000f * rate) % duration
    }
    fun frame(now: Long, mode: String, rate: Float, viseme: String, weight: Float): Frame {
        if (start < 0 || now < lastFrame) { start = now; prevStart = now; previous = null; lastMode = ""; lastFrame = now; faceAmount = 0f; faceViseme = "NEUTRAL" }
        if (mode != lastMode) {
            val next = when (mode) {
                "SPEAKING" -> talk[talkIndex++ % talk.size]
                "LISTENING" -> "Mixamo_Thoughtful_Head_Nod"
                "THINKING" -> "Mixamo_Thinking"
                // Existing wave has device-reported twist. Enable only after visual QA.
                else -> "Mixamo_Idle"
            }.let { if (it in durations) it else "Mixamo_Idle" }
            if (next != current) { previous = current; prevStart = start; prevRate = currentRate; current = next; start = now; currentRate = if (mode == "SPEAKING") rate.coerceIn(.7f,1.3f) else 1f }
            lastMode = mode
        }
        val t = ((now-start)/300f).coerceIn(0f,1f)
        if(t >= 1f) previous = null
        val safeViseme = if (viseme in setOf("A","E","I","O","U","MBP")) viseme else "NEUTRAL"
        val desired = if (mode == "SPEAKING" && weight.isFinite() && safeViseme != "NEUTRAL") weight.coerceIn(0f,1f) else 0f
        val dt = (now-lastFrame).coerceIn(0L,100L).toFloat()
        val smoothing = (dt / 65f).coerceIn(0f,1f)
        if (desired > 0f && safeViseme != faceViseme) { faceViseme = safeViseme; faceAmount = 0f }
        faceAmount += (desired-faceAmount)*smoothing
        if (mode != "SPEAKING") { faceAmount=0f; faceViseme="NEUTRAL" }
        lastFrame=now
        val blink = now % 4700L in 4450L..4590L && mode != "ERROR"
        return Frame(current, time(current,start,now,currentRate), previous, previous?.let { time(it,prevStart,now,prevRate) } ?: 0f, t*t*(3f-2f*t), "Lena_V5_Face_"+faceViseme+if(blink) "_Blink" else "", faceAmount.coerceIn(0f,1f))
    }
}
