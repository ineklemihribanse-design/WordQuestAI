Lena V5 — WordQuest AI Android entegrasyon adayı (yayımlanmamış)

Lena_V5_Runtime.glb: 201 kemik, 73 klip (V4'teki 59 + 14 ağız/göz kırpma kontrol klibi).
LenaV5Motion.kt: hareket planlayıcısı, 300 ms geçiş, konuşma varyasyonu, ses durunca nötr ağız.
apply_lena_v5.py: yalnızca tam derlenmiş WordQuest Android kaynak ağacına uygulanır. Çalıştırma: python apply_lena_v5.py /path/to/source
Test.kt: bağımsız Kotlin testleri. build_asset.py: V4'ten GLB üretme.

Doğrulandı: GLB yapısı, Kotlin mantık testi, sentetik yama testi.
Doğrulanmadı: Android derlemesi, SceneView cihazda oynatma sırası, görsel kalite, native crash ve gerçek cihazdaki TTS cue saat tabanı. Android TTS metin aralığı bilgisi yaklaşık dudak eşlemesidir; fonem hassasiyeti garanti edilmez. Oturma, dalga ve tebrik hareketleri ilk runtime sürümünde etkinleştirilmemiştir.
Orijinal uygulama, imza, paket kimliği, sürüm ve kullanıcı verileri değiştirilmedi. Test dalı dışında kullanılmamalıdır.
