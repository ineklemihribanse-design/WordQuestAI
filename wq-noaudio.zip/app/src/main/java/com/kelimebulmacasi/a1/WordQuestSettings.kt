package com.kelimebulmacasi.a1

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Slider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics

@Composable
internal fun WordQuestSettings(session: AppSession, pronunciation: WordPronunciation, back: () -> Unit) {
    val preferences = session.preferences
    LaunchedEffect(Unit) { pronunciation.inspect() }
    LaunchedEffect(preferences.speechRate, preferences.speechVolume) {
        pronunciation.configure(preferences.speechRate, preferences.speechVolume)
    }
    ScreenPage("Ayarlar", session.learningProfileName, back) {
        if (session.accountName == null) LocalProfilePicker(session)
        Text("Yazı boyutu", color = Ink, fontFamily = Serif, fontSize = 25.sp)
        for (size in AppTextSize.entries) {
            FilterChip(
                selected = preferences.textSize == size,
                onClick = { session.changePreferences(preferences.copy(textSize = size)) },
                label = { Text(size.label, fontFamily = Sans) },
            )
        }
        Text("Yazılı telaffuz (IPA)", color = Ink, fontFamily = Serif, fontSize = 23.sp)
        SoundSwitch("Amerikan ve Britanya IPA göster", preferences.showIpa, true) {
            session.changePreferences(preferences.copy(showIpa = it))
        }
        SoundSwitch("Türkçe yaklaşık okunuşu da göster", preferences.showTurkishApprox, preferences.showIpa) {
            session.changePreferences(preferences.copy(showTurkishApprox = it))
        }
        WordIpa("water", preferences)
        Text("IPA, uygulamadaki US/UK eSpeak ses profillerinin sesbirim çıktısından türetilmiştir. " +
            "İnsan editörlü sözlük doğrulaması değildir; çok anlamlı kelimelerin tek bir okunuşu " +
            "kesin kabul edilmez.", fontFamily = Sans, fontSize = 12.sp)
        Text("İngilizce telaffuz", color = Ink, fontFamily = Serif, fontSize = 25.sp)
        SoundSwitch("Kelime seslendirmesi", preferences.pronunciation, true) {
            if (!it) pronunciation.stop()
            session.changePreferences(preferences.copy(pronunciation = it))
        }
        SoundSwitch("Doğru kelimeyi otomatik oku", preferences.autoPronunciation, preferences.pronunciation) {
            session.changePreferences(preferences.copy(autoPronunciation = it))
        }
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            for (voice in EnglishVoice.entries) {
                FilterChip(
                    selected = preferences.voice == voice, enabled = preferences.pronunciation,
                    onClick = {
                        pronunciation.stop()
                        session.changePreferences(preferences.copy(voice = voice))
                    },
                    label = { Text(voice.label, fontFamily = Sans) },
                )
            }
        }
        OutlinedButton(
            onClick = { pronunciation.pronounce(listOf("schedule"), preferences.voice, replay = true) },
            enabled = preferences.pronunciation,
        ) { Text("Örnek sesi dinle", fontFamily = Sans) }
        Text("Konuşma hızı: %.2f".format(preferences.speechRate), fontFamily = Sans)
        Slider(value = preferences.speechRate, onValueChange = {
            session.changePreferences(preferences.copy(speechRate = it))
        }, valueRange = 0.5f..1.5f, enabled = preferences.pronunciation)
        Text("Ses seviyesi: %d%%".format((preferences.speechVolume * 100).toInt()), fontFamily = Sans)
        Slider(value = preferences.speechVolume, onValueChange = {
            session.changePreferences(preferences.copy(speechVolume = it))
        }, valueRange = 0f..1f, enabled = preferences.pronunciation)
        Text("Amerikan / Britanya karşılaştırması", color = Ink, fontFamily = Serif, fontSize = 23.sp)
        Text("Amerikan ve Britanya kayıtları uygulamanın içinde ayrı OGG dosyalarıdır. Android TTS ayarları gerekli değildir.", fontFamily = Sans)
        for (word in listOf("Water", "Tomato", "Better", "Can't", "Schedule")) {
            Text(word, fontFamily = Sans, fontWeight = FontWeight.SemiBold)
            WordIpa(word, preferences)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pronunciation.pronounce(listOf(word), EnglishVoice.American, replay = true) },
                    enabled = preferences.pronunciation) { Text("US dinle") }
                OutlinedButton(onClick = { pronunciation.pronounce(listOf(word), EnglishVoice.British, replay = true) },
                    enabled = preferences.pronunciation) { Text("UK dinle") }
            }
        }
        Text("Çevrimdışı aksan paketleri", color = Ink, fontFamily = Serif, fontSize = 19.sp)
        Text(pronunciation.accentDiagnostics, fontFamily = Sans)
        Text(pronunciation.voiceDetails, fontFamily = Sans)
        Text("Bu kayıtlar eSpeak ile sentezlenmiştir; doğal insan kaydı değildir. En belirgin aksan farkı için Tomato, Can't ve Schedule sözcüklerini karşılaştırın.",
            fontFamily = Sans, fontSize = 12.sp)
        pronunciation.error?.let { BodyText(it, ErrorInk) }
    }
}

@Composable
private fun SoundSwitch(text: String, checked: Boolean, enabled: Boolean, change: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, Modifier.weight(1f), color = Ink, fontFamily = Sans, fontWeight = FontWeight.SemiBold)
        Switch(checked, onCheckedChange = change, enabled = enabled,
            modifier = Modifier.semantics { contentDescription = text })
    }
}
