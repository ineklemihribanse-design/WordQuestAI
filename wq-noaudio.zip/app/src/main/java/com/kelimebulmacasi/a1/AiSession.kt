package com.kelimebulmacasi.a1

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import java.util.concurrent.CancellationException

internal enum class TeacherMode(val label: String, val prompt: String) {
    Practice("Pratik", "Practise English interactively with one natural follow-up question."),
    Grammar("Dilbilgisi", "Explain the relevant grammar rule clearly in Turkish, then give three English examples and one short check question."),
    Lesson("Kişisel ders", "Teach a short, structured CEFR-appropriate lesson using the learner's weak vocabulary, with examples and a short exercise."),
    Correction("Hata düzelt", "Correct the learner's English. Show the corrected version, explain key changes in Turkish and give a similar practice sentence."),
}

class AiSession : ViewModel() {
    private var geminiKey by mutableStateOf("")
    private var keyChange = 0
    private var nextTurn = 0L
    private var store: TeacherStore? = null
    internal var boundProfile by mutableStateOf<String?>(null)
        private set
    internal val hasKey get() = geminiKey.isNotEmpty()

    internal var turns by mutableStateOf(emptyList<ConversationTurn>())
        private set
    internal var threads by mutableStateOf(emptyList<TeacherThread>())
        private set
    internal var threadId by mutableStateOf<String?>(null)
        private set
    internal var search by mutableStateOf("")
    internal var teacherNotes by mutableStateOf("")
        private set
    internal var mode by mutableStateOf(TeacherMode.Practice)
    internal var draft by mutableStateOf("")
    internal var language by mutableStateOf(ConversationLanguage.English)
    internal var level by mutableStateOf("A2")
    internal var autoRead by mutableStateOf(true)

    internal fun bindProfile(context: Context, profileKey: String) {
        if (boundProfile == profileKey) return
        store?.close()
        store = null
        boundProfile = null
        forgetKey() // Never share an API key or a conversation across profiles.
        draft = ""
        turns = emptyList()
        threads = emptyList()
        threadId = null
        search = ""
        teacherNotes = ""
        mode = TeacherMode.Practice
        language = ConversationLanguage.English
        level = "A2"
        autoRead = true
        nextTurn = 0
        val next = TeacherStore(context, profileKey)
        store = next
        teacherNotes = next.notes()
        threads = next.threads()
        threads.firstOrNull()?.let { openThread(it.id) }
        boundProfile = profileKey
    }

    internal fun forgetKey() {
        geminiKey = ""
        keyChange++
    }

    internal fun newConversation() {
        threadId = null
        turns = emptyList()
        draft = ""
    }

    internal fun openThread(id: String) {
        val history = store ?: return
        val metadata = history.threads().firstOrNull { it.id == id } ?: return
        val loaded = history.turns(id)
        language = ConversationLanguage.entries.firstOrNull { it.name == metadata.language }
            ?: ConversationLanguage.English
        level = metadata.level.takeIf { it in conversationLevels } ?: "A2"
        threadId = id
        turns = loaded
        nextTurn = maxOf(nextTurn, loaded.maxOfOrNull { it.id } ?: 0L)
        draft = ""
    }

    internal fun deleteThread(id: String) {
        store?.delete(id)
        if (threadId == id) newConversation()
        refreshThreads()
    }

    internal fun searchThreads(term: String) {
        search = term.take(120)
        refreshThreads()
    }

    internal fun saveTeacherNotes(text: String) {
        teacherNotes = text.take(1_500)
        store?.setNotes(teacherNotes)
    }

    private fun refreshThreads() {
        threads = store?.threads(search) ?: emptyList()
    }

    internal suspend fun suggestWords(key: String, topic: String, level: String, count: Int, used: Set<String>): List<WordPair> =
        withGeminiKey(key) { requestOnlineWords(it, topic, level, count, used) }

    internal suspend fun reply(key: String, message: String, learningContext: String = ""): ConversationTurn {
        val owner = boundProfile ?: error("Öğretmen profili hazır değil")
        val activeStore = store ?: error("Öğretmen geçmişi açılamadı")
        val activeThread = threadId
        val answer = withGeminiKey(key) {
            requestConversationReply(it, nextTurn + 1, turns, message, language, level, mode, teacherNotes, learningContext)
        }
        if (owner != boundProfile || activeStore !== store || activeThread != threadId) {
            throw CancellationException("Öğretmen profili veya sohbet değişti")
        }
        // Persist before updating the visible conversation: no silent in-memory-only success.
        val savedId = activeStore.append(activeThread, answer, level)
        nextTurn = answer.id
        threadId = savedId
        turns = turns + answer
        refreshThreads()
        return answer
    }

    private suspend fun <T> withGeminiKey(input: String, request: suspend (String) -> T): T {
        val activeKey = normalizeGeminiKey(input.ifBlank { geminiKey })
        val keyVersion = keyChange
        val response = try {
            request(activeKey)
        } catch (problem: WordRequestException) {
            if (problem.invalidKey && keyVersion == keyChange && geminiKey == activeKey) forgetKey()
            throw problem
        }
        if (keyVersion == keyChange && geminiKey != activeKey) {
            geminiKey = activeKey
            keyChange++
        }
        return response
    }

    override fun onCleared() {
        store?.close()
        store = null
        super.onCleared()
    }
}
