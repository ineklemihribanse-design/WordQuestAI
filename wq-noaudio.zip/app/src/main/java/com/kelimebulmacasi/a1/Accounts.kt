package com.kelimebulmacasi.a1

import android.annotation.SuppressLint
import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.MetadataChanges
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

class Accounts(private val context: Context) {
    private val clientId = context.getString(R.string.cloud_web_client_id).trim()
    private val project = context.getString(R.string.cloud_project_id).trim()
    private val appId = context.getString(R.string.cloud_application_id).trim()
    private val key = context.getString(R.string.cloud_api_key).trim()
    private val credentials by lazy { CredentialManager.create(context) }

    private val app = if (listOf(clientId, project, appId, key).any(String::isBlank)) null else {
        FirebaseApp.getApps(context).firstOrNull { it.name == "KelimeBulmacasi" }
            ?: FirebaseApp.initializeApp(context, FirebaseOptions.Builder()
                .setProjectId(project).setApplicationId(appId).setApiKey(key).build(), "KelimeBulmacasi")
    }
    private val auth = app?.let(FirebaseAuth::getInstance)
    private val database = app?.let(FirebaseFirestore::getInstance)

    val available get() = auth != null
    val uid get() = auth?.currentUser?.uid
    val displayName get() = auth?.currentUser?.displayName ?: auth?.currentUser?.email

    // The CustomCredential below is checked and parsed by GoogleIdTokenCredential.
    @SuppressLint("CredentialManagerSignInWithGoogle")
    suspend fun signIn(): String? {
        val service = auth ?: return "Google girişi için Firebase yapılandırması gerekiyor."
        return try {
            val option = GetSignInWithGoogleOption.Builder(clientId).build()
            val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
            val credential = credentials.getCredential(context, request).credential
            if (credential !is CustomCredential ||
                credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                "Google hesabı doğrulanamadı."
            } else {
                val token = GoogleIdTokenCredential.createFrom(credential.data).idToken
                service.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).awaitResult()
                null
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (_: GetCredentialCancellationException) {
            null
        } catch (_: Exception) {
            "Google girişi tamamlanamadı. Bağlantını kontrol edip tekrar dene."
        }
    }

    fun signOut(scope: CoroutineScope) {
        auth?.signOut()
        scope.launch { runCatching { credentials.clearCredentialState(ClearCredentialStateRequest()) } }
    }

    fun connect(
        uid: String,
        store: PlayerStore,
        scope: CoroutineScope,
        onChange: () -> Unit,
        onStatus: (String) -> Unit,
    ): CloudSync? = database?.let { db ->
        val preferences = context.getSharedPreferences("cloud_install", Context.MODE_PRIVATE)
        val device = preferences.getString("id", null) ?: UUID.randomUUID().toString().also {
            preferences.edit().putString("id", it).apply()
        }
        CloudSync(db, uid, device, store, scope, onChange, onStatus)
    }
}

private suspend fun <T> com.google.android.gms.tasks.Task<T>.awaitResult(): T =
    kotlinx.coroutines.suspendCancellableCoroutine { continuation ->
        addOnSuccessListener { if (continuation.isActive) continuation.resumeWith(Result.success(it)) }
        addOnFailureListener { if (continuation.isActive) continuation.resumeWith(Result.failure(it)) }
        addOnCanceledListener { continuation.cancel() }
    }

class CloudSync(
    db: FirebaseFirestore,
    uid: String,
    private val device: String,
    private val store: PlayerStore,
    private val scope: CoroutineScope,
    private val onChange: () -> Unit,
    private val onStatus: (String) -> Unit,
) {
    private val user = db.collection("users").document(uid)
    private val listeners = mutableListOf<ListenerRegistration>()
    private val pending = mutableSetOf<String>()
    private var batch: Job? = null
    private var remoteProgressReady = false
    private var remoteCustomReady = false
    private var remoteSessionReady = false
    private var syncFailed = false

    private fun reportStatus() {
        onStatus(when {
            syncFailed -> "Eşitleme bekliyor. Kayıtlar cihazda duruyor."
            remoteProgressReady && remoteCustomReady && remoteSessionReady -> "Hesapla eşitlendi."
            else -> "Kayıtlar eşitleniyor…"
        })
    }

    init {
        listeners += user.collection("progress").addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
            if (error != null) { syncFailed = true; reportStatus() }
            else if (snapshot != null) {
                var changed = false
                for (doc in snapshot.documents) {
                    val id = doc.getString("gameId") ?: continue
                    val remote = doc.getString("data")?.let {
                        runCatching { JSONObject(it).toProgress() }.getOrNull()
                    } ?: continue
                    val local = store.read(id)
                    val merged = local.merge(remote)
                    if (merged != local) {
                        store.save(id, merged)
                        changed = true
                    }
                }
                if (changed) onChange()
                remoteProgressReady = !snapshot.metadata.isFromCache && !snapshot.metadata.hasPendingWrites()
                reportStatus()
            }
        }
        listeners += user.collection("custom").addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
            if (error != null) { syncFailed = true; reportStatus() }
            if (snapshot != null) {
                val incoming = snapshot.documentChanges.mapNotNull { doc ->
                    doc.document.getString("data")?.let {
                        runCatching { JSONObject(it).toCustomGame() }.getOrNull()
                    }
                }
                if (incoming.isNotEmpty() && store.saveCustom(incoming)) onChange()
                remoteCustomReady = !snapshot.metadata.isFromCache && !snapshot.metadata.hasPendingWrites()
                reportStatus()
            }
        }
        listeners += user.collection("sessions").addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
            if (error != null) { syncFailed = true; reportStatus() }
            val latest = snapshot?.documents?.maxByOrNull { it.getLong("openedAt") ?: 0L }
            val openedAt = latest?.getLong("openedAt") ?: 0L
            if (openedAt > store.lastGameAt) {
                store.recordLastGame(latest?.getString("gameId"), openedAt)
                onChange()
            }
            if (snapshot != null) {
                remoteSessionReady = !snapshot.metadata.isFromCache && !snapshot.metadata.hasPendingWrites()
                reportStatus()
            }
        }
        store.progress().keys.forEach(pending::add)
        flush()
        store.savedGames().forEach(::saveCustom)
        saveSession()
    }

    fun schedule(gameId: String) {
        pending.add(gameId)
        batch?.cancel()
        batch = scope.launch {
            delay(700)
            flush()
        }
    }

    fun flush() {
        batch?.cancel()
        batch = null
        for (id in pending) {
            val progress = store.read(id)
            user.collection("progress").document(id + "_" + device).set(
                mapOf("gameId" to id, "data" to progress.toJson().toString()),
            ).addOnFailureListener { syncFailed = true; reportStatus() }
        }
        pending.clear()
    }

    fun saveCustom(game: Game) {
        user.collection("custom").document(game.id + "_" + device).set(mapOf("data" to game.toJson().toString()))
            .addOnFailureListener { syncFailed = true; reportStatus() }
    }

    fun saveSession() {
        val id = store.lastGame ?: return
        user.collection("sessions").document(device)
            .set(mapOf("gameId" to id, "openedAt" to store.lastGameAt))
            .addOnFailureListener { syncFailed = true; reportStatus() }
    }

    fun close() {
        flush()
        listeners.forEach(ListenerRegistration::remove)
    }
}
