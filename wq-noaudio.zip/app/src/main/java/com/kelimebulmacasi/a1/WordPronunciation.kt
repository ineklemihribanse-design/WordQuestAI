package com.kelimebulmacasi.a1

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Puzzle and vocabulary playback uses local US/GB recordings, not Android TTS. */
internal class WordPronunciation(context: Context) {
    private val player = OfflineAccentPlayer(context)
    private var rate = 0.9f
    private var volume = 1f
    private var closed = false

    var voiceDetails by mutableStateOf("Çevrimdışı ses paketi henüz denetlenmedi.")
        private set
    var accentDiagnostics by mutableStateOf("Ses kayıtları denetlenmedi.")
        private set
    var error by mutableStateOf<String?>(null)
        private set

    fun inspect() {
        if (closed) return
        val count = player.dictionarySize
        accentDiagnostics = if (count > 0)
            "US: $count çevrimdışı kayıt (eSpeak en-us)\nUK: $count çevrimdışı kayıt (eSpeak en-gb)\n" +
                "Telefonun metin okuma motoru ve İngilizce paketleri gerekmez."
        else "UYARI: Çevrimdışı telaffuz kayıtları bu uygulama paketinde yok."
        if (count == 0) error = "Çevrimdışı ses paketi bulunamadı; uygulamayı ses varlıklarıyla birlikte yeniden derleyin."
    }

    fun configure(rate: Float, level: Float) {
        this.rate = rate.coerceIn(0.5f, 1.5f)
        this.volume = level.coerceIn(0f, 1f)
        player.configure(this.rate, this.volume)
    }

    fun pronounce(words: List<String>, preferred: EnglishVoice, replay: Boolean = false) {
        if (closed) return
        error = null
        voiceDetails = "${preferred.locale.toLanguageTag()} · eSpeak ${preferred.locale.toLanguageTag().lowercase()} · " +
            "uygulamaya gömülü bağımsız ses kaydı (Android TTS kullanılmıyor)"
        player.play(words, preferred, rate, volume, { error = it })
    }

    fun stop() {
        player.stop()
        error = null
    }

    fun close() {
        closed = true
        player.close()
    }
}
