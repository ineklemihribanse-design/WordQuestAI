package com.kelimebulmacasi.a1

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppSession(context: Context, private val accounts: Accounts, private val scope: CoroutineScope) {
    private val context = context.applicationContext
    private val catalog = Catalog(context)
    internal val verbs by lazy {
        this.context.assets.open("verb-forms.txt").bufferedReader().use { loadVerbForms(it.readLines()) }
    }
    private val guest = PlayerStore(this.context)
    private val secondPlayer by lazy { PlayerStore(this.context, secondLocalProfile = true) }
    private val localProfiles = this.context.getSharedPreferences("wordquest_local_profiles", Context.MODE_PRIVATE)
    private val preferenceStore = PreferenceStore(this.context)
    var localProfile by mutableIntStateOf(localProfiles.getInt("active", 1))
        private set
    internal var profileKey by mutableStateOf("local_$localProfile")
        private set
    internal var preferences by mutableStateOf(preferenceStore.load(profileKey))
        private set
    private var player = localPlayer()
    private var cloud: CloudSync? = null
    private var learning = localLearningStore()
    private var learningRevision by mutableIntStateOf(0)
    var learningError by mutableStateOf<String?>(null)
        private set

    internal fun searchLearning(query: String, offset: Int, limit: Int) =
        learningRevision.let { learning.cards(query, offset, limit) }
    internal fun learningCard(key: String) = learningRevision.let { learning.card(key) }
    internal fun learningHistory(key: String, offset: Int, limit: Int) =
        learningRevision.let { learning.history(key, offset, limit) }
    internal fun dueLearningCards(now: Long) = learningRevision.let { learning.dueCards(now) }
    internal fun learningDueCount(now: Long = System.currentTimeMillis()) =
        learningRevision.let { learning.countDue(now) }

    /** Short, bounded evidence summary; derived only from the currently active player's learning DB. */
    internal fun teacherLearningContext(): String = runCatching {
        val cards = searchLearning("", 0, 500)
        val trouble = cards.filter { it.wrong > 0 || it.hints > 0 || it.forgotten > 0 }
            .sortedByDescending { it.wrong * 3 + it.forgotten * 3 + it.hints }
            .take(8)
        val lines = trouble.joinToString("; ") { card ->
            "${card.answer.take(40)} (${card.clue.take(60)}): ${card.wrong} yanlış, ${card.hints} ipucu, ${card.forgotten} tekrar hatası"
        }
        "Tekrar bekleyen kelime: ${learningDueCount()}; üzerinde çalışılacak kelimeler: ${lines.ifBlank { "Henüz kayıtlı hata yok" }}"
            .take(1_500)
    }.getOrDefault("Öğrenme kayıtları şu anda okunamadı.")

    internal fun recordLearning(game: Game, signal: LearningSignal) {
        runCatching { learning.record(game.progressId, signal) }
            .onSuccess {
                if (it) learningRevision++
                learningError = null
            }
            .onFailure { learningError = "Kelime öğrenme kaydı yazılamadı: depolama alanını kontrol et." }
    }

    internal fun reviewLearning(card: LearningCard, rating: ReviewRating) {
        runCatching { learning.review(card, rating) }
            .onSuccess {
                if (it) learningRevision++
                learningError = null
            }
            .onFailure { learningError = "Tekrar kaydı saklanamadı." }
    }

    internal fun pinLearning(card: LearningCard, pinned: Boolean) {
        runCatching { learning.pin(card, pinned) }
            .onSuccess {
                learningRevision++
                learningError = null
            }
            .onFailure { learningError = "Kelime defteri güncellenemedi." }
    }

    val accountAvailable get() = accounts.available
    val learningProfileName get() = accountName ?: "Oyuncu $localProfile"
    var accountName by mutableStateOf<String?>(null)
        private set
    var accountError by mutableStateOf<String?>(null)
        private set
    var accountStatus by mutableStateOf("")
        private set
    var signInBusy by mutableStateOf(false)
        private set
    private var revision by mutableIntStateOf(0)

    init { openAccount() }

    internal fun changePreferences(next: WordQuestPreferences) {
        preferenceStore.save(profileKey, next)
        preferences = next
    }

    val games: List<Game> get() = catalog.games + savedGames + originalGame
    private val savedGames: List<Game> get() = revision.let { player.savedGames() }
    val customGames: List<Game> get() = savedGames.filter { it.mode == GameMode.Custom }
    internal suspend fun vocabulary(): VocabularyBank = withContext(Dispatchers.Default) { catalog.vocabulary }
    val records: Map<String, Progress> get() {
        val progress = revision.let { player.progress() }
        return games.mapNotNull { game -> progress[game.progressId]?.let { game.id to it } }.toMap()
    }
    val totalPoints get() = revision.let { player.progress().values.sumOf(Progress::points) }
    val finishedCount get() = records.values.count(Progress::completed)
    val continueGame: Game? get() {
        val progress = records
        val allGames = games
        val last = allGames.firstOrNull { it.id == player.lastGame }
        if (last != null) {
            val record = progress[last.id]
            if (record == null || record.lockedWords.size != last.wordCount) return last
        }
        return allGames.filter { game ->
            val record = progress[game.id]
            record != null && record.started && record.lockedWords.size != game.wordCount
        }.maxByOrNull { progress.getValue(it.id).updatedAt }
    }

    fun game(id: String) = catalog.byId[id] ?: originalGame.takeIf { it.id == id } ?: savedGames.firstOrNull { it.id == id }

    internal suspend fun newGame(level: String, topic: String?, kind: String?, size: Int): Game? {
        val playerAtStart = player
        val previous = savedGames.lastOrNull { it.mode == GameMode.Generated && it.id == player.lastGame }
            ?.puzzle?.words?.map { it.entry.letters }?.toSet().orEmpty()
        val game = withContext(Dispatchers.Default) {
            generateGame(catalog.vocabulary.pool(level, topic, kind), size, level, topic, kind, previous)
        } ?: return null
        return game.takeIf { playerAtStart === player && saveCustom(listOf(it), null) }
    }

    fun record(game: Game): Progress? = revision.let { player.find(game.progressId) }

    internal fun round(game: Game, progress: Progress): BoardRound = BoardRound.open(game.puzzle, progress.layout)

    internal suspend fun shuffle(game: Game): Boolean {
        val store = player
        val before = store.read(game.progressId)
        val board = round(game, before)
        val next = withContext(Dispatchers.Default) { shuffleBoard(board.puzzle) } ?: return false
        val current = this.game(game.id)
        val latest = store.read(game.progressId)
        if (store !== player || current?.progressId != game.progressId || latest.layout != before.layout) return false
        save(game, board.moveProgress(latest, next))
        return true
    }

    fun recordOpen(game: Game) {
        player.lastGame = game.id
        cloud?.saveSession()
        revision++
    }

    fun save(game: Game, progress: Progress): Progress {
        val previous = player.read(game.progressId)
        val merged = previous.merge(progress)
        if (previous != merged) {
            player.save(game.progressId, merged)
            cloud?.schedule(game.progressId)
            revision++
        }
        return merged
    }

    fun saveCustom(games: List<Game>, expectedModifiedAt: Long?): Boolean {
        if (expectedModifiedAt != null && game(games.single().id)?.modifiedAt != expectedModifiedAt) return false
        if (!player.saveCustom(games)) return false
        games.forEach { cloud?.saveCustom(it) }
        revision++
        return true
    }

    internal suspend fun backup(): PlayerBackup {
        val base = PlayerBackup(player.savedGames(), player.progress(), player.lastGame, player.lastGameAt)
        val learningForExport = learning
        val archive = withContext(Dispatchers.IO) { learningForExport.exportArchive() }
        return base.copy(learning = archive)
    }

    internal fun restore(backup: PlayerBackup) {
        backup.learning?.let { archive ->
            learning.importArchive(archive)
            learningRevision++
        }
        player.importBackup(backup)
        val restoredIds = backup.games.map(Game::id).toSet()
        player.savedGames().filter { it.id in restoredIds }.forEach { cloud?.saveCustom(it) }
        backup.progress.keys.forEach { cloud?.schedule(it) }
        cloud?.saveSession()
        revision++
    }

    fun replay(game: Game) {
        val old = player.read(game.progressId)
        if (old.lockedWords.size == game.wordCount) {
            val round = round(game, old)
            val crossword = Crossword(round.puzzle, round.onBoard(old))
            crossword.reset()
            save(game, round.inStore(crossword.progress(), old.layoutAt))
        }
    }

    fun closeGame() {
        flush()
    }

    fun flush() = cloud?.flush()

    fun close() {
        cloud?.close()
        cloud = null
        learning.close()
    }

    fun signIn() {
        if (signInBusy) return
        accountError = null
        scope.launch {
            signInBusy = true
            try {
                accountError = accounts.signIn()
                if (accounts.uid != null) openAccount()
            } finally {
                signInBusy = false
            }
        }
    }

    fun signOut() {
        close()
        accounts.signOut(scope)
        accountName = null
        accountStatus = ""
        accountError = null
        openLocalProfile()
    }

    private fun openAccount() {
        val uid = accounts.uid ?: return
        close()
        val personal = PlayerStore(context, uid)
        if (localProfile == 1) personal.importGuest(guest)
        player = personal
        // Do not auto-copy guest learning history into another person's account.
        learning = LearningStore(context, uid)
        learningError = null
        learningRevision++
        accountName = accounts.displayName ?: "Google hesabı"
        loadPreferences("account_${stableHash(uid)}")
        accountStatus = "Kayıtlar eşitleniyor…"
        cloud = accounts.connect(uid, personal, scope, { revision++ }, { accountStatus = it })
        revision++
    }

    internal fun selectLocalProfile(profile: Int) {
        require(profile in 1..2)
        if (accountName != null || signInBusy || profile == localProfile) return
        learning.close()
        localProfile = profile
        localProfiles.edit().putInt("active", profile).apply()
        openLocalProfile()
    }

    private fun localPlayer() = if (localProfile == 2) secondPlayer else guest

    private fun localLearningStore() = LearningStore(context, null, secondLocalProfile = localProfile == 2)

    private fun openLocalProfile() {
        player = localPlayer()
        learning = localLearningStore()
        learningError = null
        learningRevision++
        loadPreferences("local_$localProfile")
        revision++
    }

    private fun loadPreferences(profile: String) {
        profileKey = profile
        preferences = preferenceStore.load(profile)
    }
}
